﻿namespace MarioGameGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.MarioHealth = new System.Windows.Forms.ProgressBar();
            this.M_Health = new System.Windows.Forms.Label();
            this.MarioScore = new System.Windows.Forms.Label();
            this.Score = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 70;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // MarioHealth
            // 
            this.MarioHealth.Location = new System.Drawing.Point(1263, 718);
            this.MarioHealth.Name = "MarioHealth";
            this.MarioHealth.Size = new System.Drawing.Size(170, 19);
            this.MarioHealth.TabIndex = 0;
            // 
            // M_Health
            // 
            this.M_Health.AutoSize = true;
            this.M_Health.BackColor = System.Drawing.Color.Transparent;
            this.M_Health.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.M_Health.Location = new System.Drawing.Point(1272, 749);
            this.M_Health.Name = "M_Health";
            this.M_Health.Size = new System.Drawing.Size(141, 25);
            this.M_Health.TabIndex = 1;
            this.M_Health.Text = "Mario Health";
            // 
            // MarioScore
            // 
            this.MarioScore.AutoSize = true;
            this.MarioScore.BackColor = System.Drawing.Color.Transparent;
            this.MarioScore.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MarioScore.Location = new System.Drawing.Point(1043, 712);
            this.MarioScore.Name = "MarioScore";
            this.MarioScore.Size = new System.Drawing.Size(120, 25);
            this.MarioScore.TabIndex = 2;
            this.MarioScore.Text = "Mario score";
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.BackColor = System.Drawing.Color.Transparent;
            this.Score.Font = new System.Drawing.Font("Modern No. 20", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.Location = new System.Drawing.Point(1091, 749);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(22, 25);
            this.Score.TabIndex = 3;
            this.Score.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::MarioGameGUI.Properties.Resources.sky;
            this.ClientSize = new System.Drawing.Size(1558, 818);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.MarioScore);
            this.Controls.Add(this.M_Health);
            this.Controls.Add(this.MarioHealth);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ProgressBar MarioHealth;
        private System.Windows.Forms.Label M_Health;
        private System.Windows.Forms.Label MarioScore;
        private System.Windows.Forms.Label Score;
    }
}

