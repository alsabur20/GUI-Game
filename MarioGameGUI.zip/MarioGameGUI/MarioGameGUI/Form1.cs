﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MarioGameGUI.GL;
using EZInput;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;

namespace MarioGameGUI
{
    public partial class Form1 : Form
    {
        private int stage = 1;
        public int counter = 0;
        Game game;
        char movementStatus = 's';
        CollisionDetection collider;

        public int Stage { get => stage; set => stage = value; }

        public Form1()
        {
            InitializeComponent();
            game = new Game(this, stage);
            collider = new CollisionDetection();

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            CheckMario();
            SetScore();
            MoveMario();
            move();
            game.RemoveFire();
            if (stage == 0)
            {
                ShowTurtleHealth();
                moveTurtle();
                MoveMarioFire();
            }
            if (stage == 1)
            {
                MoveGoombaFire();
                moveGoomba();
                game.RemoveGoombas();
                if (counter == 5)
                {
                    game.GenerateGoombaFire();
                }
                if (counter == 10)
                {
                    counter = 0;
                }
            }
            counter++;
        }
        private void CheckMario()
        {
            if (game.Mario.IsDead == true)
            {

                timer1.Stop();
                this.Hide();
                Form2 f = new Form2(game.Score, "You Loose!", MarioGameGUI.Properties.Resources.Sad_Marioo);
                f.Show();
            }
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            return true;
        }
        private void ShowTurtleHealth()
        {
            /*health.Text = game.GetHealth().ToString();*/
            MarioHealth.Value = game.GetHealth();
        }
        private void SetScore()
        {
            Score.Text = game.Score.ToString();
        }
        private void moveTurtle()
        {
            Turtle Turtle = game.Turtle1;
            if (collider.isMarioCollidedWithTurtle(Turtle))
            {
                game.Mario.Health -= 10;
            }
            if (Turtle.Health == 0)
            {
                Turtle.CurrentCell.CurrentGameObject = GameCell.getBlankGameObject();
            }
            else
            {
                Turtle.move(Turtle.nextCell());
            }
        }
        private void moveGoomba()
        {
            foreach (GoombaH g in game.Goombas)
            {
                g.move(g.nextCell());
            }
        }
        private void MoveGoombaFire()
        {
            foreach (Fire f in game.GFires)
            {
                if (collider.isMarioCollideWithBullet(f))
                {
                    if (game.Mario.Health > 0)
                    {
                        game.Mario.Health -= 10;
                    }
                    else
                    {
                        game.Mario.IsDead = true;
                    }
                }
                f.move(f.nextCell());
            }
        }
        private void MoveMarioFire()
        {
            foreach (Fire f in game.MFires)
            {
                if (collider.isTurtleCollideWithBullet(f))
                {
                    game.Turtle1.Health = game.Turtle1.Health - 5;
                }
                f.move(f.nextCell());
            }
        }

        private void MoveMario()
        {
            Mario mario = game.Mario;
            GameCell potentialNewCell = mario.CurrentCell;
            if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                mario.Direction = GameDirection.Left;
                potentialNewCell = mario.CurrentCell.nextCell(GameDirection.Left);
                GameCell currentCell = mario.CurrentCell;
                currentCell.SetGameObject(Game.getBlankGameObject());
                mario.move(potentialNewCell);
                movementStatus = 'd';
            }
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                mario.Direction = GameDirection.Right;
                potentialNewCell = mario.CurrentCell.nextCell(GameDirection.Right);
                GameCell currentCell = mario.CurrentCell;
                currentCell.SetGameObject(Game.getBlankGameObject());
                mario.move(potentialNewCell);
                movementStatus = 'd';
            }
            if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                mario.Direction = GameDirection.Up;
                movementStatus = 'u';

            }
            if (Keyboard.IsKeyPressed(Key.Space))
            {
                GameCell NewCell = mario.CurrentCell.nextCell(GameDirection.Right);
                Fire f = new Fire(MarioGameGUI.Properties.Resources.fire, NewCell, GameDirection.Right);
                game.addMarioFire(f);
            }
            if (Keyboard.IsKeyPressed(Key.A))
            {
                game.Stage = 2;
                game.SetStage();
                this.Refresh();
            }
            if (collider.isMarioCollidedWithCoin(mario))
            {
                game.Score++;
            }
        }

        private void move()
        {
            Mario mario = game.Mario;
            GameCell potentialNewCell = mario.CurrentCell;
            GameCell nextCell;
            if (movementStatus == 'u')
            {
                int jumpCount = 0;
                for (int i = 0; i < 4; i++)
                {
                    nextCell = mario.CurrentCell.nextCell(GameDirection.Up);
                    jumpCount++;
                    GameCell currentCell = mario.CurrentCell;
                    currentCell.SetGameObject(Game.getBlankGameObject());
                    mario.move(nextCell);
                }
                if (jumpCount == 4)
                {
                    mario.Direction = GameDirection.Down;
                    movementStatus = 'd';

                }
            }
            if (movementStatus == 'd')
            {
                nextCell = mario.CurrentCell.nextCell(GameDirection.Down);
                if (nextCell != potentialNewCell)
                {
                    GameCell currentCell = mario.CurrentCell;
                    currentCell.SetGameObject(Game.getBlankGameObject());
                    mario.move(nextCell);
                }
            }


        }
    }
}


